package com.example.gl20.test;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.util.Log;

public class MyRenderer implements GLSurfaceView.Renderer {

	private Triangle triangle;

	public void onSurfaceCreated(GL10 unused, EGLConfig config) {
		// Set the background frame color
		GLES20.glClearColor(0.9f, 0.9f, 0.9f, 1.0f);
		// construct a triangle object
		triangle = new Triangle();
	}

	public void onDrawFrame(GL10 unused) {
		// Redraw background color
		GLES20.glClearColor(0, 0, 0, 0);
		GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);
		triangle.draw();
		Log.d("DDDDDDDDDDDDDD", "DDDDDDDDDD");
	}

	public void onSurfaceChanged(GL10 unused, int width, int height) {
		GLES20.glViewport(0, 0, width, height);
		float ratio = (float) width / height;
	}

}
