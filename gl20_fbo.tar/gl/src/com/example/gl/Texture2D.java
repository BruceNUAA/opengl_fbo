package com.example.gl;

import java.nio.FloatBuffer;
import java.nio.IntBuffer;

import javax.microedition.khronos.opengles.GL10;

import android.graphics.Bitmap;
import android.opengl.GLUtils;

public class Texture2D {
	private int mWidth;
	private int mHeight;
	private float maxU = 5.0f;
	private float maxV = 5.0f;

	private Bitmap mBitmap = null;
	private int textureId = 0;

	public void delete(GL10 gl) {
		if (textureId != 0) {
			gl.glDeleteTextures(1, new int[] { textureId }, 0);
			textureId = 0;
		}

		if (mBitmap != null) {
			if (mBitmap.isRecycled())
				mBitmap.recycle();
			mBitmap = null;
		}
	}

	FloatBuffer verticleBuffer;
	FloatBuffer colorBuffer;
	FloatBuffer coordBuffer;

	public Texture2D(Bitmap bmp) {
		mWidth = bmp.getWidth();
		mHeight = bmp.getHeight();

		maxU = 1.0f;
		maxV = 1.0f;

		mBitmap = bmp;
	}

	public void bind(GL10 gl) {
		if (textureId == 0) {
			int[] textures = new int[1];
			gl.glGenTextures(1, textures, 0);
			textureId = textures[0];

			gl.glBindTexture(GL10.GL_TEXTURE_2D, textureId);

			gl.glTexParameterx(GL10.GL_TEXTURE_2D, GL10.GL_TEXTURE_MIN_FILTER,
					GL10.GL_LINEAR);

			GLUtils.texImage2D(GL10.GL_TEXTURE_2D, 0, mBitmap, 0);
		    mBitmap.recycle();
			mBitmap = null;
		}

		gl.glBindTexture(GL10.GL_TEXTURE_2D, textureId);
	}
	
	private float mF = 0;
	private float mStep = 0.01f;
	
	public void draw(GL10 gl, float xx, float yy) { 
		{
			float x = -0.5f;
			float y = -0.5f;

			float[] f1 = new float[] { x + 1, y + 1, x + 1, y, x, y + 1, x, y, };
			verticleBuffer = BufferUtil.newFloatBuffer(f1.length);
			verticleBuffer.put(f1);
			verticleBuffer.position(0);

			if (mF < 0 || mF > 1)
				mStep *= -1;
			
			mF += mStep;
			
			float[] color = new float[] { 
					mF, mF, mF, mF, //1, 1, 1, mF,// x + 1, y + 1,
					mF, mF, mF, mF, //1, 1, 1, mF,// x + 1, y,
					mF, mF, mF, mF, //1, 1, 1, mF,// x, y + 1,
					mF, mF, mF, mF, //1, 1, 1, mF,// x, y,
			};
			
			colorBuffer = BufferUtil.newFloatBuffer(color.length);
			colorBuffer.put(color);

			colorBuffer.position(0);

			float[] f2 = new float[] { 0, 0, maxU, 0, 0, maxV, maxU, maxV, };
			coordBuffer = BufferUtil.newFloatBuffer(f2.length);
			coordBuffer.put(f2);
			coordBuffer.position(0);
		}
		
		gl.glEnable(GL10.GL_TEXTURE_2D);
		gl.glEnable(GL10.GL_POINT_SMOOTH);
		gl.glEnableClientState(GL10.GL_TEXTURE_COORD_ARRAY);
		gl.glEnableClientState(GL10.GL_VERTEX_ARRAY);
		gl.glEnableClientState(GL10.GL_COLOR_ARRAY);

		this.bind(gl);

		gl.glVertexPointer(2, GL10.GL_FLOAT, 0, verticleBuffer);
		gl.glTexCoordPointer(2, GL10.GL_FLOAT, 0, coordBuffer);
		gl.glColorPointer(4, GL10.GL_FLOAT, 0, colorBuffer);

		gl.glLoadIdentity();

		gl.glRotatef(3f, 0.0f, 0.0f, -1.0f);
		gl.glDrawArrays(GL10.GL_TRIANGLE_STRIP, 0, 4);

		gl.glDisableClientState(GL10.GL_VERTEX_ARRAY);
		gl.glDisableClientState(GL10.GL_TEXTURE_COORD_ARRAY);
		gl.glDisableClientState(GL10.GL_COLOR_ARRAY);
		gl.glDisable(GL10.GL_TEXTURE_2D);
	}

	public void draw(GL10 gl, float x, float y, float width, float height) {
		gl.glEnable(GL10.GL_TEXTURE_2D);
		gl.glEnableClientState(GL10.GL_TEXTURE_COORD_ARRAY);
		gl.glEnableClientState(GL10.GL_VERTEX_ARRAY);

		// 绑定
		bind(gl);

		// 映射
		// 映射
		FloatBuffer verticleBuffer = FloatBuffer.wrap(new float[] { x, y,
				x + width, 0, x, y + height, x + width, y + height, });
		FloatBuffer coordBuffer = FloatBuffer.wrap(new float[] { 0, 0, maxU, 0,
				0, maxV, maxU, maxV, });

		gl.glTexCoordPointer(2, GL10.GL_FLOAT, 0, coordBuffer);
		gl.glVertexPointer(2, GL10.GL_FLOAT, 0, verticleBuffer);

		gl.glDrawArrays(GL10.GL_TRIANGLE_STRIP, 0, 4);

		gl.glDisableClientState(GL10.GL_VERTEX_ARRAY);
		gl.glDisableClientState(GL10.GL_TEXTURE_COORD_ARRAY);
		gl.glDisable(GL10.GL_TEXTURE_2D);

	}

}
