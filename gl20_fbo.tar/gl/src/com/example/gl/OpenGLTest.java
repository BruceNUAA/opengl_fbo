package com.example.gl;

import javax.microedition.khronos.egl.EGL10;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.egl.EGLDisplay;
import javax.microedition.khronos.opengles.GL10;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PixelFormat;
import android.opengl.GLSurfaceView;
import android.util.AttributeSet;

public class OpenGLTest extends GLSurfaceView {
    public OpenGLTest(Context context, AttributeSet attrs) {
        super(context, attrs);

        setEGLConfigChooser(new EGLConfigChooser() {
            @Override
            public EGLConfig chooseConfig(EGL10 egl, EGLDisplay display) {
                int[] attrList = new int[] { //
                EGL10.EGL_SURFACE_TYPE, EGL10.EGL_WINDOW_BIT, //
                        EGL10.EGL_DEPTH_SIZE, 24, //
                        EGL10.EGL_BUFFER_SIZE, 32,//
                        EGL10.EGL_SAMPLE_BUFFERS, 1,//
                        EGL10.EGL_SAMPLES, 4, //
                        EGL10.EGL_NONE //
                };

                EGLConfig[] configOut = new EGLConfig[1];
                int[] configNumOut = new int[1];
                egl.eglChooseConfig(display, attrList, configOut, 1,
                        configNumOut);
                return configOut[0];
            }
        });

        setZOrderOnTop(true);

        
        setRenderer(new GLRenderer(context));getHolder().setFormat(PixelFormat.TRANSLUCENT);
    }

    class GLRenderer implements GLSurfaceView.Renderer {
        Texture2D texture;
        Texture2D tx;

        GLRenderer(Context context) {
            Bitmap test_img = BitmapFactory.decodeResource(
                    context.getResources(), R.drawable.port_img);
            texture = new Texture2D(test_img);
            test_img = BitmapFactory.decodeResource(
                    context.getResources(), R.drawable.img);
            tx = new Texture2D(test_img);
        }

        public void onSurfaceCreated(GL10 gl, EGLConfig config) {
            // Log.d("DDD", "onSurfaceCreated");
            // gl.glClearColor(0.5f, 0.5f, 0.5f, 0.0f); //设置清除色
        	gl.glEnable(GL10.GL_BLEND);
 
        	gl.glBlendFunc(GL10.GL_SRC_ALPHA, GL10.GL_ONE_MINUS_DST_ALPHA);
        }

        public void onSurfaceChanged(GL10 gl, int width, int height) {
            // texture.draw(gl, 0, 0);
            // Log.d("DDD", "onSurfaceChanged");
            // gl.glViewport(0, 0, width, height);//设置视口
            // float ratio=(float)width/(float)height;//width height 为屏幕的宽度和高度
            // gl.glOrthof(-ratio,ratio,1,1,1,-1);//
        };

        public void onDrawFrame(GL10 gl) {
        
            gl.glClear(GL10.GL_COLOR_BUFFER_BIT | GL10.GL_DEPTH_BUFFER_BIT);
            gl.glLoadIdentity();

            gl.glViewport(0, 0, getWidth(), getHeight());
            gl.glOrthof(-1, 1, -1, 1, 0, 0);

           
            tx.draw(gl, 1, 0); texture.draw(gl, 0, 0);
        };

    };
}
